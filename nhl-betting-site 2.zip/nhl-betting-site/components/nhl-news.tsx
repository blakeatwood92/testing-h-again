"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, ExternalLink } from "lucide-react"
import Image from "next/image"

interface NewsItem {
  id: string
  headline: string
  summary: string
  date: string
  source: string
  url: string
  category: string
  image?: string
}

export function NHLNews() {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const getMockNews = () => {
    const now = new Date()
    return [
      {
        id: "1",
        headline: "McDavid Leads Oilers to Victory Over Flames",
        summary: "Connor McDavid scored twice as Edmonton defeated Calgary 4-2 in Battle of Alberta",
        date: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
        source: "BetHockey.ca",
        url: "#",
        category: "Game Recap",
        image: "/placeholder.svg?height=80&width=120&text=McDavid",
      },
      {
        id: "2",
        headline: "Maple Leafs Shopping for Defensive Help",
        summary: "Toronto reportedly in talks with multiple teams ahead of trade deadline",
        date: new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString(),
        source: "TSN",
        url: "#",
        category: "Trade Rumors",
        image: "/placeholder.svg?height=80&width=120&text=TOR",
      },
      {
        id: "3",
        headline: "Betting Trends: Canadian Teams Heating Up",
        summary: "All seven Canadian NHL teams showing strong betting value this week",
        date: new Date(now.getTime() - 6 * 60 * 60 * 1000).toISOString(),
        source: "BetHockey.ca",
        url: "#",
        category: "Betting Analysis",
        image: "/placeholder.svg?height=80&width=120&text=CAN",
      },
      {
        id: "4",
        headline: "Injury Update: Pastrnak Expected to Return",
        summary: "Bruins star forward could be back in lineup for tonight's game vs Rangers",
        date: new Date(now.getTime() - 8 * 60 * 60 * 1000).toISOString(),
        source: "Sportsnet",
        url: "#",
        category: "Injury Report",
        image: "/placeholder.svg?height=80&width=120&text=BOS",
      },
      {
        id: "5",
        headline: "Sportsbook Spotlight: Best NHL Props This Week",
        summary: "Our experts break down the top player prop bets for Canadian bettors",
        date: new Date(now.getTime() - 12 * 60 * 60 * 1000).toISOString(),
        source: "BetHockey.ca",
        url: "#",
        category: "Betting Tips",
        image: "/placeholder.svg?height=80&width=120&text=PROPS",
      },
      {
        id: "6",
        headline: "Canucks Goalie Controversy Continues",
        summary: "Vancouver still undecided on starting goaltender for upcoming road trip",
        date: new Date(now.getTime() - 16 * 60 * 60 * 1000).toISOString(),
        source: "The Province",
        url: "#",
        category: "Team News",
        image: "/placeholder.svg?height=80&width=120&text=VAN",
      },
    ]
  }

  useEffect(() => {
    const fetchNHLNews = async () => {
      try {
        // Try to fetch real news first
        const response = await fetch("/api/nhl-news", {
          next: { revalidate: 600 }, // 10 minutes
        })

        if (response.ok) {
          const data = await response.json()
          setNewsItems(data.articles || [])
          setError(null)
        } else {
          throw new Error("News API unavailable")
        }
      } catch (error) {
        console.log("Using mock news data")
        setNewsItems(getMockNews())
        setError("Using demo news - Live news temporarily unavailable")
      } finally {
        setLoading(false)
      }
    }

    fetchNHLNews()

    // Refresh news every 10 minutes
    const interval = setInterval(fetchNHLNews, 10 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const getTimeAgo = (dateString: string) => {
    const now = new Date()
    const date = new Date(dateString)
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
      return `${diffInMinutes} minutes ago`
    } else if (diffInHours < 24) {
      return `${diffInHours} hours ago`
    } else {
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays} days ago`
    }
  }

  const getCategoryColor = (category: string) => {
    const colors = {
      "Game Recap": "bg-green-100 text-green-800",
      "Trade Rumors": "bg-orange-100 text-orange-800",
      "Betting Analysis": "bg-blue-100 text-blue-800",
      "Injury Report": "bg-red-100 text-red-800",
      "Betting Tips": "bg-purple-100 text-purple-800",
      "Team News": "bg-gray-100 text-gray-800",
    }
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-400 rounded-full animate-pulse" />
            Loading NHL News...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex space-x-3 p-3 border rounded-lg animate-pulse">
                <div className="w-20 h-15 bg-gray-200 rounded flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-4 bg-gray-200 rounded" />
                    <div className="w-20 h-3 bg-gray-200 rounded" />
                  </div>
                  <div className="w-full h-4 bg-gray-200 rounded" />
                  <div className="w-3/4 h-3 bg-gray-200 rounded" />
                  <div className="w-12 h-3 bg-gray-200 rounded" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
          Latest NHL News
          {error && (
            <Badge variant="outline" className="text-xs text-orange-600">
              Demo Mode
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <p className="text-xs text-orange-700">{error}</p>
          </div>
        )}

        <div className="space-y-4">
          {newsItems.map((item) => (
            <a
              key={item.id}
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex space-x-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
            >
              <Image
                src={item.image || "/placeholder.svg?height=60&width=80&text=NEWS"}
                alt={item.headline}
                width={80}
                height={60}
                className="rounded object-cover flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Badge className={`text-xs ${getCategoryColor(item.category)}`}>{item.category}</Badge>
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {getTimeAgo(item.date)}
                  </div>
                </div>
                <h3 className="font-medium text-sm leading-tight mb-1 line-clamp-2">{item.headline}</h3>
                <p className="text-xs text-gray-600 line-clamp-2 mb-2">{item.summary}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">{item.source}</span>
                  <ExternalLink className="h-3 w-3 text-gray-400" />
                </div>
              </div>
            </a>
          ))}
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">News updates every 10 minutes • BetHockey.ca</p>
        </div>
      </CardContent>
    </Card>
  )
}
