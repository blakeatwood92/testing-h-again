"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock } from "lucide-react"
import Image from "next/image"

interface APIGame {
  id: number
  date: string
  time: string
  timestamp: number
  timezone: string
  status: {
    long: string
    short: string
    timer: string | null
  }
  teams: {
    home: {
      id: number
      name: string
      logo: string
    }
    away: {
      id: number
      name: string
      logo: string
    }
  }
  scores: {
    home: number
    away: number
  }
}

interface UpcomingGame {
  id: string
  date: string
  homeTeam: {
    id: number
    city: string
    name: string
    abbreviation: string
    logo: string
  }
  awayTeam: {
    id: number
    city: string
    name: string
    abbreviation: string
    logo: string
  }
  venue: string
}

export function UpcomingGames() {
  const [games, setGames] = useState<UpcomingGame[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const parseTeamName = (fullName: string) => {
    const teamMappings: { [key: string]: { city: string; name: string; abbreviation: string } } = {
      "Toronto Maple Leafs": { city: "Toronto", name: "Maple Leafs", abbreviation: "TOR" },
      "Montreal Canadiens": { city: "Montreal", name: "Canadiens", abbreviation: "MTL" },
      "Calgary Flames": { city: "Calgary", name: "Flames", abbreviation: "CGY" },
      "Edmonton Oilers": { city: "Edmonton", name: "Oilers", abbreviation: "EDM" },
      "Vancouver Canucks": { city: "Vancouver", name: "Canucks", abbreviation: "VAN" },
      "Winnipeg Jets": { city: "Winnipeg", name: "Jets", abbreviation: "WPG" },
      "Ottawa Senators": { city: "Ottawa", name: "Senators", abbreviation: "OTT" },
      "Boston Bruins": { city: "Boston", name: "Bruins", abbreviation: "BOS" },
      "New York Rangers": { city: "New York", name: "Rangers", abbreviation: "NYR" },
      "New York Islanders": { city: "New York", name: "Islanders", abbreviation: "NYI" },
      "Pittsburgh Penguins": { city: "Pittsburgh", name: "Penguins", abbreviation: "PIT" },
      "Philadelphia Flyers": { city: "Philadelphia", name: "Flyers", abbreviation: "PHI" },
      "Detroit Red Wings": { city: "Detroit", name: "Red Wings", abbreviation: "DET" },
      "Chicago Blackhawks": { city: "Chicago", name: "Blackhawks", abbreviation: "CHI" },
      "Tampa Bay Lightning": { city: "Tampa Bay", name: "Lightning", abbreviation: "TBL" },
      "Florida Panthers": { city: "Florida", name: "Panthers", abbreviation: "FLA" },
      "Carolina Hurricanes": { city: "Carolina", name: "Hurricanes", abbreviation: "CAR" },
      "Nashville Predators": { city: "Nashville", name: "Predators", abbreviation: "NSH" },
      "Washington Capitals": { city: "Washington", name: "Capitals", abbreviation: "WSH" },
      "Columbus Blue Jackets": { city: "Columbus", name: "Blue Jackets", abbreviation: "CBJ" },
      "New Jersey Devils": { city: "New Jersey", name: "Devils", abbreviation: "NJD" },
      "Buffalo Sabres": { city: "Buffalo", name: "Sabres", abbreviation: "BUF" },
      "Colorado Avalanche": { city: "Colorado", name: "Avalanche", abbreviation: "COL" },
      "Dallas Stars": { city: "Dallas", name: "Stars", abbreviation: "DAL" },
      "Minnesota Wild": { city: "Minnesota", name: "Wild", abbreviation: "MIN" },
      "St. Louis Blues": { city: "St. Louis", name: "Blues", abbreviation: "STL" },
      "Arizona Coyotes": { city: "Arizona", name: "Coyotes", abbreviation: "ARI" },
      "Vegas Golden Knights": { city: "Vegas", name: "Golden Knights", abbreviation: "VGK" },
      "Los Angeles Kings": { city: "Los Angeles", name: "Kings", abbreviation: "LAK" },
      "Anaheim Ducks": { city: "Anaheim", name: "Ducks", abbreviation: "ANA" },
      "San Jose Sharks": { city: "San Jose", name: "Sharks", abbreviation: "SJS" },
      "Seattle Kraken": { city: "Seattle", name: "Kraken", abbreviation: "SEA" },
    }

    return (
      teamMappings[fullName] || {
        city: fullName.split(" ").slice(0, -1).join(" "),
        name: fullName.split(" ").slice(-1)[0],
        abbreviation: fullName.substring(0, 3).toUpperCase(),
      }
    )
  }

  const fetchUpcomingGames = async () => {
    try {
      setError(null)

      // Get next few days of games
      const today = new Date()
      const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)

      const startDate = today.toISOString().split("T")[0]
      const endDate = nextWeek.toISOString().split("T")[0]

      const response = await fetch(`https://v1.hockey.api-sports.io/games?league=57&from=${startDate}&to=${endDate}`, {
        method: "GET",
        headers: {
          "x-apisports-key": "eea68bb9ffbb9d24f3f584dedc233ac6",
        },
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.response && data.response.length > 0) {
        // Filter for upcoming games (not started yet) and take first 5
        const upcomingGames = data.response
          .filter((game: APIGame) => {
            const gameTime = new Date(game.date + " " + game.time)
            return gameTime > new Date() && game.status.short === "NS" // Not Started
          })
          .slice(0, 5)
          .map((game: APIGame) => {
            const homeTeamInfo = parseTeamName(game.teams.home.name)
            const awayTeamInfo = parseTeamName(game.teams.away.name)

            return {
              id: game.id.toString(),
              date: game.date + " " + game.time,
              homeTeam: {
                id: game.teams.home.id,
                city: homeTeamInfo.city,
                name: homeTeamInfo.name,
                abbreviation: homeTeamInfo.abbreviation,
                logo: game.teams.home.logo,
              },
              awayTeam: {
                id: game.teams.away.id,
                city: awayTeamInfo.city,
                name: awayTeamInfo.name,
                abbreviation: awayTeamInfo.abbreviation,
                logo: game.teams.away.logo,
              },
              venue: `${homeTeamInfo.city} Arena`,
            }
          })

        setGames(upcomingGames)
      } else {
        // No upcoming games from API, use mock data
        setGames(getMockUpcomingGames())
        setError("Using demo schedule - Live schedule temporarily unavailable")
      }
    } catch (error) {
      console.error("API-Sports Error:", error)
      setGames(getMockUpcomingGames())
      setError("Using demo schedule - API temporarily unavailable")
    } finally {
      setLoading(false)
    }
  }

  const getMockUpcomingGames = () => {
    const today = new Date()
    const games = []

    for (let i = 0; i < 5; i++) {
      const gameDate = new Date(today.getTime() + (i + 1) * 24 * 60 * 60 * 1000)
      gameDate.setHours(19 + Math.floor(Math.random() * 3), Math.floor(Math.random() * 2) * 30, 0, 0)

      const canadianTeams = [
        { id: 10, city: "Toronto", name: "Maple Leafs", abbreviation: "TOR", logo: "" },
        { id: 8, city: "Montreal", name: "Canadiens", abbreviation: "MTL", logo: "" },
        { id: 20, city: "Calgary", name: "Flames", abbreviation: "CGY", logo: "" },
        { id: 22, city: "Edmonton", name: "Oilers", abbreviation: "EDM", logo: "" },
        { id: 23, city: "Vancouver", name: "Canucks", abbreviation: "VAN", logo: "" },
        { id: 52, city: "Winnipeg", name: "Jets", abbreviation: "WPG", logo: "" },
        { id: 9, city: "Ottawa", name: "Senators", abbreviation: "OTT", logo: "" },
      ]

      const usTeams = [
        { id: 1, city: "Boston", name: "Bruins", abbreviation: "BOS", logo: "" },
        { id: 2, city: "New York", name: "Rangers", abbreviation: "NYR", logo: "" },
        { id: 3, city: "Pittsburgh", name: "Penguins", abbreviation: "PIT", logo: "" },
        { id: 4, city: "Philadelphia", name: "Flyers", abbreviation: "PHI", logo: "" },
        { id: 5, city: "Detroit", name: "Red Wings", abbreviation: "DET", logo: "" },
        { id: 6, city: "Chicago", name: "Blackhawks", abbreviation: "CHI", logo: "" },
      ]

      const allTeams = [...canadianTeams, ...usTeams]
      const homeTeam = allTeams[Math.floor(Math.random() * allTeams.length)]
      let awayTeam = allTeams[Math.floor(Math.random() * allTeams.length)]

      while (awayTeam.id === homeTeam.id) {
        awayTeam = allTeams[Math.floor(Math.random() * allTeams.length)]
      }

      games.push({
        id: `upcoming-${i}`,
        date: gameDate.toISOString(),
        homeTeam,
        awayTeam,
        venue: `${homeTeam.city} Arena`,
      })
    }

    return games
  }

  useEffect(() => {
    fetchUpcomingGames()
  }, [])

  const formatGameTime = (gameDate: string) => {
    const date = new Date(gameDate)
    const now = new Date()
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000)

    let dateLabel = ""
    if (date.toDateString() === now.toDateString()) {
      dateLabel = "Tonight"
    } else if (date.toDateString() === tomorrow.toDateString()) {
      dateLabel = "Tomorrow"
    } else {
      dateLabel = date.toLocaleDateString("en-CA", { month: "short", day: "numeric" })
    }

    const timeLabel =
      date.toLocaleTimeString("en-CA", {
        hour: "numeric",
        minute: "2-digit",
        timeZone: "America/Toronto",
      }) + " ET"

    return { dateLabel, timeLabel }
  }

  const getMockOdds = () => {
    const odds = ["-120", "+110", "-140", "+125", "-105", "-115", "+130", "-150", "+105", "-110"]
    return {
      home: odds[Math.floor(Math.random() * odds.length)],
      away: odds[Math.floor(Math.random() * odds.length)],
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Loading Schedule...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 border rounded-lg animate-pulse">
                <div className="w-20 h-12 bg-gray-200 rounded" />
                <div className="flex items-center space-x-6 flex-1 justify-center">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-gray-200 rounded-full" />
                    <div className="w-24 h-4 bg-gray-200 rounded" />
                    <div className="w-12 h-4 bg-gray-200 rounded" />
                  </div>
                  <div className="w-4 h-4 bg-gray-200 rounded" />
                  <div className="flex items-center space-x-2">
                    <div className="w-12 h-4 bg-gray-200 rounded" />
                    <div className="w-24 h-4 bg-gray-200 rounded" />
                    <div className="w-6 h-6 bg-gray-200 rounded-full" />
                  </div>
                </div>
                <div className="w-16 h-8 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Upcoming Games
          {error && (
            <Badge variant="outline" className="text-xs text-orange-600">
              Demo Mode
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <p className="text-xs text-orange-700">{error}</p>
          </div>
        )}

        <div className="space-y-4">
          {games.map((game) => {
            const { dateLabel, timeLabel } = formatGameTime(game.date)
            const odds = getMockOdds()

            return (
              <div key={game.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center space-x-4">
                  <div className="text-center min-w-[80px]">
                    <div className="text-sm font-medium">{dateLabel}</div>
                    <div className="text-xs text-gray-500 flex items-center justify-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {timeLabel}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-6 flex-1 justify-center">
                  <div className="flex items-center space-x-2">
                    <Image
                      src={
                        game.awayTeam.logo || `/placeholder.svg?height=24&width=24&text=${game.awayTeam.abbreviation}`
                      }
                      alt={game.awayTeam.name}
                      width={24}
                      height={24}
                      className="rounded"
                      onError={(e) => {
                        e.currentTarget.src = `/placeholder.svg?height=24&width=24&text=${game.awayTeam.abbreviation}`
                      }}
                    />
                    <span className="text-sm font-medium min-w-[60px]">{game.awayTeam.abbreviation}</span>
                    <span className="text-sm font-bold text-green-600 min-w-[50px]">{odds.away}</span>
                  </div>

                  <div className="text-gray-400">@</div>

                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-green-600 min-w-[50px]">{odds.home}</span>
                    <span className="text-sm font-medium min-w-[60px]">{game.homeTeam.abbreviation}</span>
                    <Image
                      src={
                        game.homeTeam.logo || `/placeholder.svg?height=24&width=24&text=${game.homeTeam.abbreviation}`
                      }
                      alt={game.homeTeam.name}
                      width={24}
                      height={24}
                      className="rounded"
                      onError={(e) => {
                        e.currentTarget.src = `/placeholder.svg?height=24&width=24&text=${game.homeTeam.abbreviation}`
                      }}
                    />
                  </div>
                </div>

                <Button size="sm" variant="outline">
                  Bet Now
                </Button>
              </div>
            )
          })}
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">Powered by API-Sports • BetHockey.ca</p>
        </div>
      </CardContent>
    </Card>
  )
}
