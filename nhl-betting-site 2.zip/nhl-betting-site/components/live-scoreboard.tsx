"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Image from "next/image"

interface APITeam {
  id: number
  name: string
  logo: string
}

interface APIGame {
  id: number
  date: string
  time: string
  timestamp: number
  timezone: string
  status: {
    long: string
    short: string
    timer: string | null
  }
  league: {
    id: number
    name: string
    type: string
    season: string
    logo: string
  }
  country: {
    id: number
    name: string
    code: string
    flag: string
  }
  teams: {
    home: {
      id: number
      name: string
      logo: string
    }
    away: {
      id: number
      name: string
      logo: string
    }
  }
  scores: {
    home: number
    away: number
  }
  periods: {
    current: number
    total: number
    endOfPeriod: boolean
  }
}

interface NHLGame {
  id: string
  date: string
  homeTeam: {
    id: number
    city: string
    name: string
    abbreviation: string
    score: number
    logo: string
  }
  awayTeam: {
    id: number
    city: string
    name: string
    abbreviation: string
    score: number
    logo: string
  }
  gameState: string
  gameStateDetailed: string
  period: number
  timeRemaining: string
  intermission: boolean
}

export function LiveScoreboard() {
  const [games, setGames] = useState<NHLGame[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const parseTeamName = (fullName: string) => {
    // Parse team names to get city and team name
    const teamMappings: { [key: string]: { city: string; name: string; abbreviation: string } } = {
      "Toronto Maple Leafs": { city: "Toronto", name: "Maple Leafs", abbreviation: "TOR" },
      "Montreal Canadiens": { city: "Montreal", name: "Canadiens", abbreviation: "MTL" },
      "Calgary Flames": { city: "Calgary", name: "Flames", abbreviation: "CGY" },
      "Edmonton Oilers": { city: "Edmonton", name: "Oilers", abbreviation: "EDM" },
      "Vancouver Canucks": { city: "Vancouver", name: "Canucks", abbreviation: "VAN" },
      "Winnipeg Jets": { city: "Winnipeg", name: "Jets", abbreviation: "WPG" },
      "Ottawa Senators": { city: "Ottawa", name: "Senators", abbreviation: "OTT" },
      "Boston Bruins": { city: "Boston", name: "Bruins", abbreviation: "BOS" },
      "New York Rangers": { city: "New York", name: "Rangers", abbreviation: "NYR" },
      "New York Islanders": { city: "New York", name: "Islanders", abbreviation: "NYI" },
      "Pittsburgh Penguins": { city: "Pittsburgh", name: "Penguins", abbreviation: "PIT" },
      "Philadelphia Flyers": { city: "Philadelphia", name: "Flyers", abbreviation: "PHI" },
      "Detroit Red Wings": { city: "Detroit", name: "Red Wings", abbreviation: "DET" },
      "Chicago Blackhawks": { city: "Chicago", name: "Blackhawks", abbreviation: "CHI" },
      "Tampa Bay Lightning": { city: "Tampa Bay", name: "Lightning", abbreviation: "TBL" },
      "Florida Panthers": { city: "Florida", name: "Panthers", abbreviation: "FLA" },
      "Carolina Hurricanes": { city: "Carolina", name: "Hurricanes", abbreviation: "CAR" },
      "Nashville Predators": { city: "Nashville", name: "Predators", abbreviation: "NSH" },
      "Washington Capitals": { city: "Washington", name: "Capitals", abbreviation: "WSH" },
      "Columbus Blue Jackets": { city: "Columbus", name: "Blue Jackets", abbreviation: "CBJ" },
      "New Jersey Devils": { city: "New Jersey", name: "Devils", abbreviation: "NJD" },
      "Buffalo Sabres": { city: "Buffalo", name: "Sabres", abbreviation: "BUF" },
      "Colorado Avalanche": { city: "Colorado", name: "Avalanche", abbreviation: "COL" },
      "Dallas Stars": { city: "Dallas", name: "Stars", abbreviation: "DAL" },
      "Minnesota Wild": { city: "Minnesota", name: "Wild", abbreviation: "MIN" },
      "St. Louis Blues": { city: "St. Louis", name: "Blues", abbreviation: "STL" },
      "Arizona Coyotes": { city: "Arizona", name: "Coyotes", abbreviation: "ARI" },
      "Vegas Golden Knights": { city: "Vegas", name: "Golden Knights", abbreviation: "VGK" },
      "Los Angeles Kings": { city: "Los Angeles", name: "Kings", abbreviation: "LAK" },
      "Anaheim Ducks": { city: "Anaheim", name: "Ducks", abbreviation: "ANA" },
      "San Jose Sharks": { city: "San Jose", name: "Sharks", abbreviation: "SJS" },
      "Seattle Kraken": { city: "Seattle", name: "Kraken", abbreviation: "SEA" },
    }

    return (
      teamMappings[fullName] || {
        city: fullName.split(" ").slice(0, -1).join(" "),
        name: fullName.split(" ").slice(-1)[0],
        abbreviation: fullName.substring(0, 3).toUpperCase(),
      }
    )
  }

  const fetchLiveGames = async () => {
    try {
      setError(null)

      // Fetch live games from API-Sports
      const response = await fetch("https://v1.hockey.api-sports.io/games?live=all&league=57", {
        method: "GET",
        headers: {
          "x-apisports-key": "eea68bb9ffbb9d24f3f584dedc233ac6",
        },
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`)
      }

      const data = await response.json()

      if (!data.response || data.response.length === 0) {
        // No live games, fetch today's games instead
        const today = new Date().toISOString().split("T")[0]
        const todayResponse = await fetch(`https://v1.hockey.api-sports.io/games?league=57&date=${today}`, {
          method: "GET",
          headers: {
            "x-apisports-key": "eea68bb9ffbb9d24f3f584dedc233ac6",
          },
        })

        if (todayResponse.ok) {
          const todayData = await todayResponse.json()
          const transformedGames = transformAPIGames(todayData.response || [])
          setGames(transformedGames)
        } else {
          setGames([])
        }
      } else {
        const transformedGames = transformAPIGames(data.response)
        setGames(transformedGames)
      }
    } catch (err) {
      console.error("API-Sports Error:", err)
      setError("Unable to load live scores from API")
      // Use mock data as fallback
      const mockData = getMockLiveGames()
      setGames(mockData.games)
    } finally {
      setLoading(false)
    }
  }

  const transformAPIGames = (apiGames: APIGame[]): NHLGame[] => {
    return apiGames.map((game) => {
      const homeTeamInfo = parseTeamName(game.teams.home.name)
      const awayTeamInfo = parseTeamName(game.teams.away.name)

      let gameState = "SCHEDULED"
      let gameStateDetailed = game.status.long
      let period = 1
      let timeRemaining = ""

      // Map API status to our format
      if (
        game.status.short === "LIVE" ||
        game.status.short === "1P" ||
        game.status.short === "2P" ||
        game.status.short === "3P"
      ) {
        gameState = "LIVE"
        period = game.periods?.current || 1
        timeRemaining = game.status.timer || "20:00"
      } else if (game.status.short === "FT" || game.status.short === "AOT" || game.status.short === "SO") {
        gameState = "FINAL"
        gameStateDetailed = "Final"
      }

      return {
        id: game.id.toString(),
        date: game.date,
        homeTeam: {
          id: game.teams.home.id,
          city: homeTeamInfo.city,
          name: homeTeamInfo.name,
          abbreviation: homeTeamInfo.abbreviation,
          score: game.scores?.home || 0,
          logo: game.teams.home.logo,
        },
        awayTeam: {
          id: game.teams.away.id,
          city: awayTeamInfo.city,
          name: awayTeamInfo.name,
          abbreviation: awayTeamInfo.abbreviation,
          score: game.scores?.away || 0,
          logo: game.teams.away.logo,
        },
        gameState,
        gameStateDetailed,
        period,
        timeRemaining,
        intermission: game.periods?.endOfPeriod || false,
      }
    })
  }

  const getMockLiveGames = () => {
    const currentDate = new Date()
    const currentHour = currentDate.getHours()

    const mockGames = []

    if (currentHour >= 19 || currentHour <= 1) {
      mockGames.push(
        {
          id: "mock-1",
          date: currentDate.toISOString(),
          homeTeam: {
            id: 10,
            city: "Toronto",
            name: "Maple Leafs",
            abbreviation: "TOR",
            score: Math.floor(Math.random() * 4) + 1,
            logo: "",
          },
          awayTeam: {
            id: 8,
            city: "Montreal",
            name: "Canadiens",
            abbreviation: "MTL",
            score: Math.floor(Math.random() * 4) + 1,
            logo: "",
          },
          gameState: "LIVE",
          gameStateDetailed: "In Progress",
          period: Math.floor(Math.random() * 3) + 1,
          timeRemaining: `${Math.floor(Math.random() * 20)}:${String(Math.floor(Math.random() * 60)).padStart(2, "0")}`,
          intermission: false,
        },
        {
          id: "mock-2",
          date: currentDate.toISOString(),
          homeTeam: {
            id: 20,
            city: "Calgary",
            name: "Flames",
            abbreviation: "CGY",
            score: Math.floor(Math.random() * 3),
            logo: "",
          },
          awayTeam: {
            id: 22,
            city: "Edmonton",
            name: "Oilers",
            abbreviation: "EDM",
            score: Math.floor(Math.random() * 4) + 1,
            logo: "",
          },
          gameState: "LIVE",
          gameStateDetailed: "In Progress",
          period: 2,
          timeRemaining: "8:45",
          intermission: false,
        },
      )
    }

    mockGames.push({
      id: "mock-3",
      date: currentDate.toISOString(),
      homeTeam: {
        id: 23,
        city: "Vancouver",
        name: "Canucks",
        abbreviation: "VAN",
        score: 4,
        logo: "",
      },
      awayTeam: {
        id: 52,
        city: "Winnipeg",
        name: "Jets",
        abbreviation: "WPG",
        score: 2,
        logo: "",
      },
      gameState: "FINAL",
      gameStateDetailed: "Final",
      period: 3,
      timeRemaining: "00:00",
      intermission: false,
    })

    return { games: mockGames }
  }

  useEffect(() => {
    fetchLiveGames()
    // Refresh every 30 seconds for live games
    const interval = setInterval(fetchLiveGames, 30000)
    return () => clearInterval(interval)
  }, [])

  const getGameStatus = (game: NHLGame) => {
    if (game.gameState === "LIVE") {
      const periodNames = ["1st", "2nd", "3rd", "OT", "SO"]
      const periodName = periodNames[game.period - 1] || `${game.period}OT`

      return {
        status: "LIVE",
        detail: game.intermission ? `${periodName} INT` : `${periodName} ${game.timeRemaining}`,
        isLive: true,
      }
    } else if (game.gameState === "FINAL") {
      return {
        status: "FINAL",
        detail: game.gameStateDetailed,
        isLive: false,
      }
    } else {
      return {
        status: "SCHEDULED",
        detail: new Date(game.date).toLocaleTimeString("en-CA", {
          hour: "numeric",
          minute: "2-digit",
          timeZone: "America/Toronto",
        }),
        isLive: false,
      }
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-400 rounded-full animate-pulse" />
            Loading NHL Scores...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 border rounded-lg animate-pulse">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gray-200 rounded-full" />
                  <div className="w-24 h-4 bg-gray-200 rounded" />
                  <div className="w-8 h-6 bg-gray-200 rounded" />
                </div>
                <div className="w-16 h-6 bg-gray-200 rounded" />
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-6 bg-gray-200 rounded" />
                  <div className="w-24 h-4 bg-gray-200 rounded" />
                  <div className="w-8 h-8 bg-gray-200 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (games.length === 0 && !error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-400 rounded-full" />
            NHL Scores
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">No NHL games today</p>
            <p className="text-sm text-gray-500">Check back during the NHL season for live scores</p>
            <Button size="sm" variant="outline" onClick={fetchLiveGames} className="mt-4 bg-transparent">
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
          Live NHL Scores
          {error && (
            <Badge variant="outline" className="text-xs text-orange-600">
              Demo Mode
            </Badge>
          )}
          <span className="text-sm font-normal text-gray-500">(Updates every 30s)</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <p className="text-sm text-orange-700">{error}</p>
            <Button size="sm" variant="outline" onClick={fetchLiveGames} className="mt-2 text-xs bg-transparent">
              Try Live Data
            </Button>
          </div>
        )}

        <div className="space-y-4">
          {games.map((game) => {
            const gameStatus = getGameStatus(game)
            return (
              <div key={game.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center space-x-4 flex-1">
                  <div className="flex items-center space-x-2">
                    <Image
                      src={
                        game.awayTeam.logo || `/placeholder.svg?height=32&width=32&text=${game.awayTeam.abbreviation}`
                      }
                      alt={game.awayTeam.name}
                      width={32}
                      height={32}
                      className="rounded"
                      onError={(e) => {
                        e.currentTarget.src = `/placeholder.svg?height=32&width=32&text=${game.awayTeam.abbreviation}`
                      }}
                    />
                    <div className="text-left">
                      <div className="font-medium text-sm">{game.awayTeam.abbreviation}</div>
                      <div className="text-xs text-gray-500">{game.awayTeam.city}</div>
                    </div>
                  </div>
                  <div className="text-xl font-bold min-w-[2rem] text-center">{game.awayTeam.score}</div>
                </div>

                <div className="text-center px-4">
                  <Badge variant={gameStatus.isLive ? "destructive" : "secondary"}>
                    {gameStatus.isLive ? gameStatus.detail : gameStatus.status}
                  </Badge>
                  {!gameStatus.isLive && gameStatus.status === "SCHEDULED" && (
                    <div className="text-xs text-gray-500 mt-1">{gameStatus.detail}</div>
                  )}
                </div>

                <div className="flex items-center space-x-4 flex-1 justify-end">
                  <div className="text-xl font-bold min-w-[2rem] text-center">{game.homeTeam.score}</div>
                  <div className="flex items-center space-x-2">
                    <div className="text-right">
                      <div className="font-medium text-sm">{game.homeTeam.abbreviation}</div>
                      <div className="text-xs text-gray-500">{game.homeTeam.city}</div>
                    </div>
                    <Image
                      src={
                        game.homeTeam.logo || `/placeholder.svg?height=32&width=32&text=${game.homeTeam.abbreviation}`
                      }
                      alt={game.homeTeam.name}
                      width={32}
                      height={32}
                      className="rounded"
                      onError={(e) => {
                        e.currentTarget.src = `/placeholder.svg?height=32&width=32&text=${game.homeTeam.abbreviation}`
                      }}
                    />
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">Powered by API-Sports • Updates every 30 seconds • BetHockey.ca</p>
        </div>
      </CardContent>
    </Card>
  )
}
