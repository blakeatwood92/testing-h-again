import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "BetHockey.ca | Canada's Premier NHL Betting Hub",
  description:
    "BetHockey.ca - Canada's most trusted source for NHL betting tips, sportsbook reviews, and live hockey scores. Expert picks and betting guides for Canadian hockey fans.",
  keywords:
    "NHL betting Canada, hockey betting, Canadian sportsbooks, NHL odds, hockey picks, NHL betting tips, bethockey.ca",
  openGraph: {
    title: "BetHockey.ca | Canada's Premier NHL Betting Hub",
    description: "Canada's most trusted source for NHL betting information and expert hockey picks.",
    type: "website",
    locale: "en_CA",
    url: "https://bethockey.ca",
  },
  robots: {
    index: true,
    follow: true,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en-CA">
      <body className={inter.className}>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
