import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Trophy, AlertTriangle, Info } from "lucide-react"
import Image from "next/image"

export const metadata: Metadata = {
  title: "NHL Betting Rules & Formats | Complete Guide for Canadian Bettors",
  description:
    "Understand NHL betting rules, overtime regulations, playoff formats, and how they affect your wagers. Essential guide for hockey bettors.",
  keywords: "NHL betting rules, hockey overtime rules, NHL playoff betting, hockey betting regulations",
}

export default function BettingRulesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-16 px-4 bg-gradient-to-r from-red-900 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black/40" />
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="NHL Betting Rules"
          fill
          className="object-cover -z-10"
        />
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">NHL Betting Rules & Formats</h1>
          <p className="text-xl text-gray-200">Master the rules that affect your NHL bets and betting outcomes</p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Game Format Overview */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">NHL Game Format</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Clock className="h-8 w-8 text-blue-500 mb-2" />
                <CardTitle>Regulation Time</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Three 20-minute periods (60 minutes total)</p>
                <ul className="text-sm space-y-1">
                  <li>• 20-minute intermissions between periods</li>
                  <li>• Clock stops for penalties, goals, etc.</li>
                  <li>• Teams switch ends after each period</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Trophy className="h-8 w-8 text-yellow-500 mb-2" />
                <CardTitle>Overtime (Regular Season)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">3-on-3 sudden death (5 minutes)</p>
                <ul className="text-sm space-y-1">
                  <li>• First goal wins the game</li>
                  <li>• Winner gets 2 points, loser gets 1</li>
                  <li>• Goes to shootout if still tied</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <AlertTriangle className="h-8 w-8 text-red-500 mb-2" />
                <CardTitle>Shootout</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Best of 3 rounds, then sudden death</p>
                <ul className="text-sm space-y-1">
                  <li>• Each team gets 3 shooters initially</li>
                  <li>• Continues until one team has more goals</li>
                  <li>• Winner gets 2 points, loser gets 1</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* How Rules Affect Betting */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">How NHL Rules Affect Your Bets</h2>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Info className="h-6 w-6 text-blue-500" />
                  Moneyline Betting
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 text-green-600">Regular Season</h4>
                    <p className="text-sm mb-2">Moneyline bets include overtime and shootout results.</p>
                    <ul className="text-sm space-y-1">
                      <li>• Winner determined after OT/SO</li>
                      <li>• No "tie" option available</li>
                      <li>• Both teams can earn points</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 text-red-600">Playoffs</h4>
                    <p className="text-sm mb-2">Games continue until there's a winner (no shootouts).</p>
                    <ul className="text-sm space-y-1">
                      <li>• 20-minute sudden death OT periods</li>
                      <li>• Game continues until goal scored</li>
                      <li>• Can go multiple overtime periods</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Regulation Time Betting</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-yellow-50 p-4 rounded-lg mb-4">
                  <p className="font-semibold mb-2">Important Note:</p>
                  <p className="text-sm">
                    Some sportsbooks offer "60-minute line" or "regulation time" betting, which only counts the score
                    after 60 minutes of play.
                  </p>
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <h5 className="font-semibold mb-2">Team A Regulation</h5>
                    <p className="text-sm">Team A wins in regulation time only</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Team B Regulation</h5>
                    <p className="text-sm">Team B wins in regulation time only</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Tie (Regulation)</h5>
                    <p className="text-sm">Game tied after 60 minutes</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Puck Line Considerations</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Puck line bets (typically -1.5/+1.5) include overtime and shootout results.</p>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h5 className="font-semibold mb-2">Example Scenario:</h5>
                  <p className="text-sm mb-2">Toronto -1.5 vs Montreal +1.5</p>
                  <ul className="text-sm space-y-1">
                    <li>• If Toronto wins 3-2 in OT: Montreal +1.5 wins (lost by 1)</li>
                    <li>• If Toronto wins 2-1 in SO: Montreal +1.5 wins (lost by 1)</li>
                    <li>• If Toronto wins 4-2 in regulation: Toronto -1.5 wins</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Playoff Format */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">NHL Playoff Format</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Playoff Structure</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h5 className="font-semibold mb-2">First Round</h5>
                    <p className="text-sm">16 teams, 8 matchups, best-of-7 series</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Second Round</h5>
                    <p className="text-sm">8 teams, 4 matchups, best-of-7 series</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Conference Finals</h5>
                    <p className="text-sm">4 teams, 2 matchups, best-of-7 series</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Stanley Cup Final</h5>
                    <p className="text-sm">2 teams, 1 matchup, best-of-7 series</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Playoff Betting Differences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Badge className="mb-2">No Shootouts</Badge>
                    <p className="text-sm">Games continue with 20-minute OT periods until someone scores</p>
                  </div>
                  <div>
                    <Badge className="mb-2">Series Betting</Badge>
                    <p className="text-sm">Bet on series winner, series length, or individual game outcomes</p>
                  </div>
                  <div>
                    <Badge className="mb-2">Enhanced Props</Badge>
                    <p className="text-sm">More player and team prop bets available for playoff games</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Common Betting Rules */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">Common Sportsbook Rules</h2>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Game Postponement/Cancellation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h5 className="font-semibold mb-2 text-green-600">Postponed Games</h5>
                    <ul className="text-sm space-y-1">
                      <li>• Bets typically remain valid</li>
                      <li>• Game must be played within 24-48 hours</li>
                      <li>• Check specific sportsbook rules</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2 text-red-600">Cancelled Games</h5>
                    <ul className="text-sm space-y-1">
                      <li>• All bets are typically voided</li>
                      <li>• Stakes returned to bettors</li>
                      <li>• Parlays reduced to remaining legs</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Player Props & Injuries</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-red-50 p-4 rounded-lg mb-4">
                  <p className="font-semibold mb-2">Important:</p>
                  <p className="text-sm">
                    Always check if your target player is in the starting lineup before placing prop bets.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-semibold mb-2">Player Doesn't Play</h5>
                    <ul className="text-sm space-y-1">
                      <li>• Bet is typically voided</li>
                      <li>• Stakes returned</li>
                      <li>• Some books have "action" rules</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Player Leaves Early</h5>
                    <ul className="text-sm space-y-1">
                      <li>• Bet usually stands if player started</li>
                      <li>• Check minimum playing time rules</li>
                      <li>• Varies by sportsbook</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Live Betting Rules</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h5 className="font-semibold mb-2">Bet Acceptance</h5>
                    <p className="text-sm mb-2">Live bets are subject to rapid odds changes and may be rejected if:</p>
                    <ul className="text-sm space-y-1">
                      <li>• Significant game event occurs during bet placement</li>
                      <li>• Odds have moved substantially</li>
                      <li>• Technical issues with live feed</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Settlement</h5>
                    <p className="text-sm">
                      Live bets are settled based on the official result, regardless of any display errors during the
                      game.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Key Takeaways */}
        <section>
          <h2 className="text-3xl font-bold mb-8">Key Takeaways for NHL Bettors</h2>

          <Card>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-semibold mb-4 text-blue-600">Always Remember:</h3>
                  <ul className="space-y-2 text-sm">
                    <li>✓ Regular season games can end in OT/shootout</li>
                    <li>✓ Playoff games continue until there's a winner</li>
                    <li>✓ Check if bets include overtime results</li>
                    <li>✓ Verify player participation before prop bets</li>
                    <li>✓ Understand your sportsbook's specific rules</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-4 text-red-600">Common Mistakes:</h3>
                  <ul className="space-y-2 text-sm">
                    <li>✗ Assuming regulation-only betting</li>
                    <li>✗ Not checking lineup changes</li>
                    <li>✗ Ignoring playoff format differences</li>
                    <li>✗ Betting without reading sportsbook rules</li>
                    <li>✗ Forgetting about the loser point in regular season</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
