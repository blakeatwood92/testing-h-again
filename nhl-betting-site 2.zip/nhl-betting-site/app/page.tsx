import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, TrendingUp, Users, Star, ExternalLink } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { LiveScoreboard } from "@/components/live-scoreboard"
import { UpcomingGames } from "@/components/upcoming-games"
import { NHLNews } from "@/components/nhl-news"

export default function HomePage() {
  const topSportsbooks = [
    {
      name: "Coolbet",
      rating: 4.8,
      bonus: "100% up to $500",
      features: ["Live Betting", "NHL Props", "Canadian Friendly"],
      logo: "/coolbet-logo.png",
    },
    {
      name: "Stake",
      rating: 4.7,
      bonus: "200% up to $1000",
      features: ["Crypto Betting", "Live Streaming", "Best Odds"],
      logo: "/generic-betting-logo.png",
    },
    {
      name: "BetMGM",
      rating: 4.6,
      bonus: "$1000 Risk-Free Bet",
      features: ["NHL Boosts", "Same Game Parlays", "Mobile App"],
      logo: "/generic-sports-entertainment-logo.png",
    },
    {
      name: "DraftKings",
      rating: 4.5,
      bonus: "Bet $5, Get $200",
      features: ["DFS Integration", "Live Betting", "Promotions"],
      logo: "/draftkings-logo.png",
    },
    {
      name: "FanDuel",
      rating: 4.4,
      bonus: "$1000 No Sweat First Bet",
      features: ["Easy Interface", "Quick Payouts", "NHL Specials"],
      logo: "/generic-sports-betting-logo.png",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-r from-blue-900 via-red-800 to-blue-900">
        <div className="absolute inset-0 bg-black/40" />
        <Image src="/placeholder-9az2z.png" alt="NHL Arena" fill className="object-cover -z-10" />
        <div className="relative z-10 max-w-4xl mx-auto text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Canada's Premier <span className="text-red-500">NHL Betting</span> Hub
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            BetHockey.ca - Expert picks, live odds, and the best sportsbooks for Canadian hockey fans
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
              View Top Sportsbooks
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-black px-8 py-3 bg-transparent"
            >
              NHL Betting Guide
            </Button>
          </div>
        </div>
      </section>

      {/* Live Content Section */}
      <section className="py-12 px-4 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <LiveScoreboard />
            <div className="mt-8">
              <UpcomingGames />
            </div>
          </div>
          <div>
            <NHLNews />
          </div>
        </div>
      </section>

      {/* Top Sportsbooks Section */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Top NHL Sportsbooks for Canadians</h2>
            <p className="text-xl text-gray-600">
              Vetted and ranked by our experts for the best NHL betting experience
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topSportsbooks.map((sportsbook, index) => (
              <Card key={sportsbook.name} className="relative hover:shadow-lg transition-shadow">
                {index === 0 && <Badge className="absolute -top-2 left-4 bg-red-600 text-white">#1 CHOICE</Badge>}
                <CardHeader className="text-center">
                  <Image
                    src={sportsbook.logo || "/placeholder.svg"}
                    alt={`${sportsbook.name} logo`}
                    width={120}
                    height={60}
                    className="mx-auto mb-4"
                  />
                  <CardTitle className="flex items-center justify-center gap-2">
                    {sportsbook.name}
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-normal">{sportsbook.rating}</span>
                    </div>
                  </CardTitle>
                  <CardDescription className="text-lg font-semibold text-green-600">{sportsbook.bonus}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4">
                    {sportsbook.features.map((feature) => (
                      <li key={feature} className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Visit {sportsbook.name}
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-16 px-4 bg-blue-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">32</div>
              <div className="text-blue-200">NHL Teams Covered</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">1,000+</div>
              <div className="text-blue-200">Betting Markets</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-blue-200">Live Updates</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">5★</div>
              <div className="text-blue-200">Expert Analysis</div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Pages Preview */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Everything You Need to Know</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>How to Bet on the NHL</CardTitle>
                <CardDescription>
                  Complete guide to NHL betting including moneylines, puck lines, totals, and props
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/how-to-bet">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn NHL Betting
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Where to Bet</CardTitle>
                <CardDescription>Detailed reviews of the best sportsbooks for Canadian NHL bettors</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/where-to-bet">
                  <Button variant="outline" className="w-full bg-transparent">
                    Find Sportsbooks
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Calendar className="h-12 w-12 text-red-600 mb-4" />
                <CardTitle>NHL Betting Rules</CardTitle>
                <CardDescription>Understanding formats, overtime rules, and playoff betting specifics</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/betting-rules">
                  <Button variant="outline" className="w-full bg-transparent">
                    View Rules
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
