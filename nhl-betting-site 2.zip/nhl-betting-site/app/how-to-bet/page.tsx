import type { Metadata } from "next"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Target, Calculator, Trophy } from "lucide-react"
import Image from "next/image"

export const metadata: Metadata = {
  title: "How to Bet on the NHL | Complete Guide for Canadian Bettors",
  description:
    "Learn how to bet on NHL hockey with our comprehensive guide. Moneylines, puck lines, totals, props, and expert strategies for Canadian bettors.",
  keywords: "how to bet NHL, hockey betting guide, NHL moneyline, puck line betting, NHL totals, hockey props",
}

export default function HowToBetPage() {
  const bettingTypes = [
    {
      type: "Moneyline",
      description: "Bet on which team will win the game",
      example: "Maple Leafs -150, Canadiens +130",
      icon: <Trophy className="h-8 w-8 text-yellow-500" />,
    },
    {
      type: "Puck Line",
      description: "Hockey's version of point spread betting",
      example: "Maple Leafs -1.5 (+120), Canadiens +1.5 (-140)",
      icon: <Target className="h-8 w-8 text-blue-500" />,
    },
    {
      type: "Total (Over/Under)",
      description: "Bet on total goals scored in the game",
      example: "Over 6.5 goals (-110), Under 6.5 goals (-110)",
      icon: <Calculator className="h-8 w-8 text-green-500" />,
    },
    {
      type: "Player Props",
      description: "Bet on individual player performances",
      example: "McDavid Over 0.5 goals (+150)",
      icon: <TrendingUp className="h-8 w-8 text-red-500" />,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-16 px-4 bg-gradient-to-r from-blue-900 to-red-800 text-white">
        <div className="absolute inset-0 bg-black/40" />
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="NHL Betting Guide"
          fill
          className="object-cover -z-10"
        />
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">How to Bet on the NHL</h1>
          <p className="text-xl text-gray-200">
            Master NHL betting with our comprehensive guide for Canadian hockey fans
          </p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Betting Types */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Types of NHL Bets</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {bettingTypes.map((bet) => (
              <Card key={bet.type} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    {bet.icon}
                    <div>
                      <CardTitle>{bet.type}</CardTitle>
                      <CardDescription>{bet.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <span className="text-sm font-mono">{bet.example}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Detailed Explanations */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">Understanding NHL Betting</h2>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-6 w-6 text-yellow-500" />
                  Moneyline Betting
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  The moneyline is the simplest form of NHL betting. You're simply picking which team will win the game
                  in regulation, overtime, or shootout.
                </p>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Example:</h4>
                  <p className="mb-2">Toronto Maple Leafs -150</p>
                  <p className="mb-2">Montreal Canadiens +130</p>
                  <p className="text-sm text-gray-600">
                    The Leafs are favored (negative odds). You need to bet $150 to win $100. The Canadiens are underdogs
                    (positive odds). A $100 bet wins $130.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-6 w-6 text-blue-500" />
                  Puck Line Betting
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  The puck line is hockey's version of spread betting. The standard puck line is 1.5 goals, meaning the
                  favorite must win by 2+ goals, while the underdog can lose by 1 goal or win outright.
                </p>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Example:</h4>
                  <p className="mb-2">Edmonton Oilers -1.5 (+120)</p>
                  <p className="mb-2">Calgary Flames +1.5 (-140)</p>
                  <p className="text-sm text-gray-600">
                    Oilers must win by 2+ goals. Flames can lose by 1 goal or win outright.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-6 w-6 text-green-500" />
                  Total Goals (Over/Under)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  Totals betting involves wagering on whether the combined score of both teams will be over or under a
                  set number.
                </p>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Example:</h4>
                  <p className="mb-2">Total Goals: 6.5</p>
                  <p className="mb-2">Over 6.5 (-110) | Under 6.5 (-110)</p>
                  <p className="text-sm text-gray-600">
                    If the final score is 4-3, that's 7 total goals (Over wins). If it's 3-2, that's 5 total goals
                    (Under wins).
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Betting Strategies */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">NHL Betting Strategies</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Home Ice Advantage</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">NHL home teams win approximately 55% of games. Consider factors like:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Last line change advantage</li>
                  <li>Crowd energy and support</li>
                  <li>Familiar ice conditions</li>
                  <li>Reduced travel fatigue</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Back-to-Back Games</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Teams playing on consecutive nights often struggle:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Fatigue affects performance</li>
                  <li>Backup goalies often start</li>
                  <li>Consider betting against tired teams</li>
                  <li>Look for value on rested opponents</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Goaltender Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Goaltending is crucial in NHL betting:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Check starting goalies before betting</li>
                  <li>Consider save percentage and GAA</li>
                  <li>Look at recent form and matchup history</li>
                  <li>Backup goalies can create value opportunities</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Line Shopping</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Always compare odds across multiple sportsbooks:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Even small differences add up over time</li>
                  <li>Different books may have different totals</li>
                  <li>Shop for the best puck line odds</li>
                  <li>Consider prop bet variations</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Tips for Beginners */}
        <section>
          <h2 className="text-3xl font-bold mb-8">Tips for NHL Betting Beginners</h2>

          <Card>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 text-green-600">DO:</h3>
                  <ul className="space-y-2 text-sm">
                    <li>✓ Start with small bets while learning</li>
                    <li>✓ Focus on teams you know well</li>
                    <li>✓ Keep detailed records of your bets</li>
                    <li>✓ Set a budget and stick to it</li>
                    <li>✓ Shop for the best odds</li>
                    <li>✓ Consider injury reports and lineups</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 text-red-600">DON'T:</h3>
                  <ul className="space-y-2 text-sm">
                    <li>✗ Chase losses with bigger bets</li>
                    <li>✗ Bet on every game</li>
                    <li>✗ Ignore bankroll management</li>
                    <li>✗ Bet based on emotions or fandom</li>
                    <li>✗ Ignore the importance of goalies</li>
                    <li>✗ Bet without researching matchups</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
