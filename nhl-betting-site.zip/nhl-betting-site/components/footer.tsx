import Link from "next/link"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Image src="/hockey-puck-logo.png" alt="BetHockey.ca" width={32} height={32} />
              <span className="text-lg font-bold">
                Bet<span className="text-red-500">Hockey</span>
                <span className="text-sm">.ca</span>
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              BetHockey.ca - Canada's most trusted source for NHL betting information, expert picks, and sportsbook
              reviews.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Betting Guides</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/how-to-bet" className="hover:text-white">
                  How to Bet on NHL
                </Link>
              </li>
              <li>
                <Link href="/betting-rules" className="hover:text-white">
                  NHL Betting Rules
                </Link>
              </li>
              <li>
                <Link href="/strategies" className="hover:text-white">
                  Betting Strategies
                </Link>
              </li>
              <li>
                <Link href="/glossary" className="hover:text-white">
                  Betting Glossary
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Sportsbooks</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/where-to-bet" className="hover:text-white">
                  Best Sportsbooks
                </Link>
              </li>
              <li>
                <Link href="/reviews" className="hover:text-white">
                  Sportsbook Reviews
                </Link>
              </li>
              <li>
                <Link href="/bonuses" className="hover:text-white">
                  Welcome Bonuses
                </Link>
              </li>
              <li>
                <Link href="/promotions" className="hover:text-white">
                  Current Promotions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/privacy" className="hover:text-white">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-white">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/responsible-gambling" className="hover:text-white">
                  Responsible Gambling
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} BetHockey.ca. All rights reserved.</p>
          <p className="mt-2">Please gamble responsibly. Must be 19+ in most Canadian provinces.</p>
        </div>
      </div>
    </footer>
  )
}
