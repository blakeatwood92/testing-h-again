import type { Metadata } from "next"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, ExternalLink, Shield, Smartphone, CreditCard, Headphones, TrendingUp } from "lucide-react"
import Image from "next/image"

export const metadata: Metadata = {
  title: "Best NHL Sportsbooks for Canadians | Where to Bet on Hockey",
  description:
    "Find the best NHL sportsbooks for Canadian bettors. Compare bonuses, features, and reviews of top hockey betting sites.",
  keywords: "best NHL sportsbooks Canada, hockey betting sites, Canadian sportsbooks, NHL betting bonuses",
}

export default function WhereToBetPage() {
  const sportsbooks = [
    {
      name: "Coolbet",
      rating: 4.8,
      bonus: "100% up to $500",
      description: "Premium sportsbook with excellent NHL coverage and competitive odds",
      logo: "/placeholder.svg?height=80&width=160",
      pros: [
        "Extensive NHL betting markets",
        "Live streaming for select games",
        "Fast payouts",
        "Canadian-friendly banking",
      ],
      cons: ["Limited promotions for existing users", "Higher minimum deposits"],
      features: {
        liveStreaming: true,
        mobileApp: true,
        liveBetting: true,
        cashOut: true,
      },
      paymentMethods: ["Visa", "Mastercard", "Interac", "PayPal"],
      minDeposit: "$20",
      withdrawalTime: "24-48 hours",
    },
    {
      name: "Stake",
      rating: 4.7,
      bonus: "200% up to $1000",
      description: "Crypto-friendly sportsbook with innovative features and great NHL odds",
      logo: "/generic-betting-logo.png",
      pros: [
        "Accepts cryptocurrency",
        "Excellent live betting interface",
        "Competitive NHL odds",
        "24/7 customer support",
      ],
      cons: ["Crypto focus may not suit everyone", "Limited traditional banking options"],
      features: {
        liveStreaming: false,
        mobileApp: true,
        liveBetting: true,
        cashOut: true,
      },
      paymentMethods: ["Bitcoin", "Ethereum", "Visa", "Mastercard"],
      minDeposit: "$10",
      withdrawalTime: "Instant (Crypto)",
    },
    {
      name: "BetMGM",
      rating: 4.6,
      bonus: "$1000 Risk-Free Bet",
      description: "Established brand with comprehensive NHL betting and regular promotions",
      logo: "/placeholder.svg?height=80&width=160",
      pros: ["Strong brand reputation", "Excellent mobile app", "Regular NHL promotions", "Same-game parlays"],
      cons: ["Geographic restrictions", "Higher rollover requirements"],
      features: {
        liveStreaming: true,
        mobileApp: true,
        liveBetting: true,
        cashOut: true,
      },
      paymentMethods: ["Visa", "Mastercard", "PayPal", "Online Banking"],
      minDeposit: "$25",
      withdrawalTime: "2-5 business days",
    },
    {
      name: "DraftKings",
      rating: 4.5,
      bonus: "Bet $5, Get $200",
      description: "Popular DFS platform with excellent sportsbook integration",
      logo: "/placeholder.svg?height=80&width=160",
      pros: ["DFS integration", "User-friendly interface", "Good NHL prop selection", "Regular bonuses"],
      cons: ["Limited availability in Canada", "Complex bonus terms"],
      features: {
        liveStreaming: false,
        mobileApp: true,
        liveBetting: true,
        cashOut: true,
      },
      paymentMethods: ["Visa", "Mastercard", "PayPal"],
      minDeposit: "$15",
      withdrawalTime: "3-5 business days",
    },
    {
      name: "FanDuel",
      rating: 4.4,
      bonus: "$1000 No Sweat First Bet",
      description: "Clean interface with solid NHL betting options and quick payouts",
      logo: "/placeholder.svg?height=80&width=160",
      pros: [
        "Simple, clean interface",
        "Quick registration process",
        "Good customer service",
        "Competitive NHL totals",
      ],
      cons: ["Limited international availability", "Fewer betting markets than competitors"],
      features: {
        liveStreaming: false,
        mobileApp: true,
        liveBetting: true,
        cashOut: false,
      },
      paymentMethods: ["Visa", "Mastercard", "Online Banking"],
      minDeposit: "$20",
      withdrawalTime: "2-4 business days",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-16 px-4 bg-gradient-to-r from-green-900 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black/40" />
        <Image src="/placeholder.svg?height=400&width=1200" alt="NHL Sportsbooks" fill className="object-cover -z-10" />
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Best NHL Sportsbooks for Canadians</h1>
          <p className="text-xl text-gray-200">
            Compare top-rated sportsbooks and find the perfect platform for your NHL betting
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Quick Comparison */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Quick Comparison</h2>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-lg shadow">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sportsbook
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rating
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Welcome Bonus
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Min Deposit
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Withdrawal Time
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sportsbooks.map((book, index) => (
                  <tr key={book.name} className={index === 0 ? "bg-yellow-50" : ""}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {index === 0 && <Badge className="mr-2 bg-yellow-500 text-white">#1</Badge>}
                        <span className="font-medium">{book.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                        <span>{book.rating}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">{book.bonus}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{book.minDeposit}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{book.withdrawalTime}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Detailed Reviews */}
        <section>
          <h2 className="text-3xl font-bold mb-12">Detailed Sportsbook Reviews</h2>

          <div className="space-y-8">
            {sportsbooks.map((book, index) => (
              <Card key={book.name} className="overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-green-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      {index === 0 && <Badge className="bg-red-600 text-white">EDITOR'S CHOICE</Badge>}
                      <Image src={book.logo || "/placeholder.svg"} alt={`${book.name} logo`} width={120} height={60} />
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          {book.name}
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm font-normal ml-1">{book.rating}</span>
                          </div>
                        </CardTitle>
                        <CardDescription className="text-lg font-semibold text-green-600">{book.bonus}</CardDescription>
                      </div>
                    </div>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Visit {book.name}
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="pt-6">
                  <p className="text-gray-600 mb-6">{book.description}</p>

                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <div>
                      <h4 className="font-semibold mb-3 text-green-600">Pros</h4>
                      <ul className="space-y-1 text-sm">
                        {book.pros.map((pro) => (
                          <li key={pro} className="flex items-start">
                            <span className="text-green-500 mr-2">✓</span>
                            {pro}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3 text-red-600">Cons</h4>
                      <ul className="space-y-1 text-sm">
                        {book.cons.map((con) => (
                          <li key={con} className="flex items-start">
                            <span className="text-red-500 mr-2">✗</span>
                            {con}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3">Features</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span>Live Streaming</span>
                          <span className={book.features.liveStreaming ? "text-green-500" : "text-red-500"}>
                            {book.features.liveStreaming ? "✓" : "✗"}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Mobile App</span>
                          <span className={book.features.mobileApp ? "text-green-500" : "text-red-500"}>
                            {book.features.mobileApp ? "✓" : "✗"}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Live Betting</span>
                          <span className={book.features.liveBetting ? "text-green-500" : "text-red-500"}>
                            {book.features.liveBetting ? "✓" : "✗"}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Cash Out</span>
                          <span className={book.features.cashOut ? "text-green-500" : "text-red-500"}>
                            {book.features.cashOut ? "✓" : "✗"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3">Payment Info</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="font-medium">Min Deposit:</span>
                          <span className="ml-2">{book.minDeposit}</span>
                        </div>
                        <div>
                          <span className="font-medium">Withdrawal:</span>
                          <span className="ml-2">{book.withdrawalTime}</span>
                        </div>
                        <div>
                          <span className="font-medium">Methods:</span>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {book.paymentMethods.map((method) => (
                              <Badge key={method} variant="outline" className="text-xs">
                                {method}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* What to Look For */}
        <section className="mt-16">
          <h2 className="text-3xl font-bold mb-8">What to Look for in an NHL Sportsbook</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Shield className="h-8 w-8 text-blue-500 mb-2" />
                <CardTitle>Licensing & Security</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• Valid gambling license</li>
                  <li>• SSL encryption</li>
                  <li>• Responsible gambling tools</li>
                  <li>• Positive reputation</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Smartphone className="h-8 w-8 text-green-500 mb-2" />
                <CardTitle>Mobile Experience</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• Dedicated mobile app</li>
                  <li>• Responsive web design</li>
                  <li>• Live betting on mobile</li>
                  <li>• Easy navigation</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CreditCard className="h-8 w-8 text-purple-500 mb-2" />
                <CardTitle>Banking Options</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• Multiple deposit methods</li>
                  <li>• Fast withdrawals</li>
                  <li>• Low minimum deposits</li>
                  <li>• No hidden fees</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <TrendingUp className="h-8 w-8 text-red-500 mb-2" />
                <CardTitle>NHL Betting Markets</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• Comprehensive game coverage</li>
                  <li>• Player props</li>
                  <li>• Live betting options</li>
                  <li>• Futures markets</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Star className="h-8 w-8 text-yellow-500 mb-2" />
                <CardTitle>Competitive Odds</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• Low juice/vig</li>
                  <li>• Competitive lines</li>
                  <li>• Enhanced odds promotions</li>
                  <li>• Price boosts on NHL games</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Headphones className="h-8 w-8 text-orange-500 mb-2" />
                <CardTitle>Customer Support</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-1">
                  <li>• 24/7 availability</li>
                  <li>• Multiple contact methods</li>
                  <li>• Knowledgeable staff</li>
                  <li>• Quick response times</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </div>
  )
}
